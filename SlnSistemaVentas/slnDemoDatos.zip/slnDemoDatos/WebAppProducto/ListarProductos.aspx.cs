﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using LibDatosProducto.Models;
using LibDatosProducto.Repositorios;


namespace WebAppProducto
{
    public partial class ListarProductos : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if(!Page.IsPostBack) //la primera vez entra, es para que no se repitan los colores (puedo tocar cualquier boton y no repite)
            {
                TraerTodos();

                dbColor.Items.Add("[TODOS]");

                foreach (var item in AdminUtilitarios.traerColor())
                {
                    dbColor.Items.Add(item);
                }
            }

        }

        private void TraerTodos()
        {
            gridProductos.DataSource = AdminProducto.Listar();
            gridProductos.DataBind();
        }

        protected void btnInsertar_Click(object sender, EventArgs e)
        {
            Producto producto = new Producto() 
            { 
                Nombre = "Teclado",
                Color = "Negro",
                Precio = 850.5m
            };

            int resultado = AdminProducto.Agregar(producto);

            Producto producto2 = new Producto()
            {
                Nombre = "Teclado",
                Color = "Rojo",
                Precio = 850.5m
            };

            int resultado2 = AdminProducto.Agregar(producto2);

            Producto producto3 = new Producto()
            {
                Nombre = "Mouse",
                Color = "Azul",
                Precio = 500
            };

            int resultado3 = AdminProducto.Agregar(producto3);


        }

        protected void btnModificar_Click(object sender, EventArgs e)
        {
            Producto producto = new Producto()
            {
                Id = 1,
                Nombre = "Teclado Inalambrico",
                Color = "Negro",
                Precio = 850.5m
            };

            int resultado = AdminProducto.Modificar(producto);

        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            int resultado = AdminProducto.Eliminar(3);
        }

        protected void btnAgregarCategoria_Click(object sender, EventArgs e)
        {
            Categoria nueva = new Categoria("Hardware", "Componentes para armar una PC");
            Categoria nueva2 = new Categoria("Software", "Solo programas de Diseño");
            Categoria nueva3 = new Categoria("Software", "Solo programas de Ofimática");

            int resultado = AdminCategoria.Agregar(nueva);
            int resultado2 = AdminCategoria.Agregar(nueva2);
            int resultado3 = AdminCategoria.Agregar(nueva3);
        }

        protected void btnModificarCategoria_Click(object sender, EventArgs e)
        {
            Categoria categoria = new Categoria { Id = 2, Nombre = "Software", Descripcion = " programas de Diseño y de Ofimática" };
            int resultado = AdminCategoria.Modificar(categoria);
        }

        protected void btnEliminarCategoria_Click(object sender, EventArgs e)
        {
            int resultado = AdminCategoria.Eliminar(3);
        }

        protected void btnColor_Click(object sender, EventArgs e)
        {
            gridProductos.DataSource = AdminProducto.Listar(txtColor.Text);
            gridProductos.DataBind();
        }

        protected void btnTraerProducto_Click(object sender, EventArgs e)
        {
            Producto producto = AdminProducto.traerProducto(1);
            lblTraerUnProducto.Text = producto.Nombre + " " + producto.Precio.ToString();
        }

        protected void dbColor_SelectedIndexChanged(object sender, EventArgs e)
        {
            string color = dbColor.SelectedItem.ToString();

            if (color == "[TODOS]")
            {
                TraerTodos();
            }
            else
            {
                gridProductos.DataSource = AdminProducto.Listar(color);
                gridProductos.DataBind();
            }

           
        }
    }
}