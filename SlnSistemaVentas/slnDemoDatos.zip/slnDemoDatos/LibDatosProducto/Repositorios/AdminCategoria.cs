﻿using LibDatosProducto.BaseDatos;
using LibDatosProducto.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibDatosProducto.Repositorios
{
    public static class AdminCategoria
    {
        private static SqlCommand command;
        private static SqlDataReader reader;
        public static int Agregar(Categoria categoria)
        {
            string consulta = "INSERT INTO dbo.Categoria(Nombre,Descripcion) VALUES(@Nombre,@Descripcion)";

            command = new SqlCommand(consulta, AdminDB.conectarDB());

            command.Parameters.Add("@Nombre", System.Data.SqlDbType.VarChar, 50).Value = categoria.Nombre;
            command.Parameters.Add("@Descripcion", System.Data.SqlDbType.VarChar, 150).Value = categoria.Descripcion;

            int filasAfectadas = command.ExecuteNonQuery();

            AdminDB.conectarDB().Close();

            return filasAfectadas;
        }

        public static int Modificar(Categoria categoria)
        {
            string consulta = "UPDATE dbo.Categoria SET Nombre = @Nombre ,Descripcion = @Descripcion WHERE Id = @Id";

            command = new SqlCommand(consulta, AdminDB.conectarDB());

            command.Parameters.Add("@Nombre", System.Data.SqlDbType.VarChar, 50).Value = categoria.Nombre;
            command.Parameters.Add("@Descripcion", System.Data.SqlDbType.VarChar, 150).Value = categoria.Descripcion;
            command.Parameters.Add("@Id", System.Data.SqlDbType.Int).Value = categoria.Id;

            int filasAfectadas = command.ExecuteNonQuery();

            AdminDB.conectarDB().Close();

            return filasAfectadas;
        }

        public static int Eliminar(int id)
        {
            string consulta = "DELETE FROM dbo.Categoria where Id = @Id";

            command = new SqlCommand(consulta, AdminDB.conectarDB());

            command.Parameters.Add("@Id", System.Data.SqlDbType.Int).Value = id;

            int filasAfectadas = command.ExecuteNonQuery();

            AdminDB.conectarDB().Close();

            return filasAfectadas;
        }


    }
}
