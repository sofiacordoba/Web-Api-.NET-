﻿using LibDatosProducto.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using LibDatosProducto.BaseDatos;
using System.Data;

namespace LibDatosProducto.Repositorios
{
    public static class AdminProducto
    {
        private static SqlCommand command;
        private static SqlDataReader reader;
        public static int Modificar(Producto producto)
        {
            string consulta = "UPDATE [dbo].[Producto] SET Nombre = @Nombre ,Color = @Color , Precio = @Precio WHERE Id = @Id";

            command = new SqlCommand(consulta,AdminDB.conectarDB());

            command.Parameters.Add("@Nombre", System.Data.SqlDbType.VarChar, 50).Value = producto.Nombre;
            command.Parameters.Add("@Color", System.Data.SqlDbType.VarChar, 50).Value = producto.Color;
            command.Parameters.Add("@Precio", System.Data.SqlDbType.Money).Value = producto.Precio;
            command.Parameters.Add("@Id", System.Data.SqlDbType.Int).Value = producto.Id;

            int filasAfectadas = command.ExecuteNonQuery();

            AdminDB.conectarDB().Close();

            return filasAfectadas;
        }

        public static int Eliminar(int id)
        {
            string consulta = "DELETE FROM dbo.Producto where Id = @Id";

            command = new SqlCommand(consulta, AdminDB.conectarDB());

            command.Parameters.Add("@Id", System.Data.SqlDbType.Int).Value = id;

            int filasAfectadas = command.ExecuteNonQuery();

            AdminDB.conectarDB().Close();

            return filasAfectadas;
        }

        public static List<Producto> Listar(string color)
        {
            string consulta = "SELECT Id,Nombre,Color,Precio FROM dbo.Producto where Color = @Color";
            command = new SqlCommand(consulta, AdminDB.conectarDB());
            command.Parameters.Add("@Color", SqlDbType.VarChar, 50).Value = color;
            SqlDataReader reader = command.ExecuteReader();
            List<Producto> productos = new List<Producto>();
            while (reader.Read())
            {
                productos.Add(new Producto()
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    Nombre = reader["Nombre"].ToString(),
                    Color = reader["Color"].ToString(),
                    Precio = Convert.ToDecimal(reader["Precio"])
                });
            }
            reader.Close();
            AdminDB.conectarDB().Close();

            return productos;
        }

        public static List<Producto> Listar()
        {
            string consulta = "SELECT Id,Nombre,Color,Precio FROM dbo.Producto";
            command = new SqlCommand(consulta, AdminDB.conectarDB());
            SqlDataReader reader = command.ExecuteReader();
            List<Producto> productos = new List<Producto>();
            while (reader.Read())
            {
                productos.Add(new Producto()
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    Nombre = reader["Nombre"].ToString(),
                    Color = reader["Color"].ToString(),
                    Precio = Convert.ToDecimal(reader["Precio"])
                });
            }
            reader.Close();
            AdminDB.conectarDB().Close();

            return productos;
        }


        public static Producto traerProducto(int id)
        {
            string consulta = "SELECT Id,Nombre,Color,Precio FROM dbo.Producto where Id = @Id";
            command = new SqlCommand(consulta, AdminDB.conectarDB());
            command.Parameters.Add("@Id", SqlDbType.Int).Value = id; //modificamos
            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                Producto producto = null;
                while (reader.Read())
                {
                    producto = new Producto() //modificamos
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Nombre = reader["Nombre"].ToString(),
                        Color = reader["Color"].ToString(),
                        Precio = Convert.ToDecimal(reader["Precio"])
                    };
                }

                reader.Close();
                AdminDB.conectarDB().Close();

                return producto;
            }
            else
            {
                AdminDB.conectarDB().Close();
                return null;
            }


        }

        public static int Agregar(Producto producto)
        {
            string consulta = "INSERT INTO dbo.Producto(Nombre,Color,Precio) VALUES (@Nombre,@Color,@Precio)";

            command = new SqlCommand(consulta, AdminDB.conectarDB());

            command.Parameters.Add("@Nombre", System.Data.SqlDbType.VarChar, 50).Value = producto.Nombre;
            command.Parameters.Add("@Color", System.Data.SqlDbType.VarChar, 50).Value = producto.Color;
            command.Parameters.Add("@Precio", System.Data.SqlDbType.Money).Value = producto.Precio;
            
            int filasAfectadas = command.ExecuteNonQuery();

            AdminDB.conectarDB().Close();

            return filasAfectadas;
        }


    }
}
