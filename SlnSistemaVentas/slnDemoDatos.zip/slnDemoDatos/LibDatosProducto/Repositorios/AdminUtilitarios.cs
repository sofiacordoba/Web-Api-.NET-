﻿using LibDatosProducto.BaseDatos;
using LibDatosProducto.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibDatosProducto.Repositorios
{
    public static class AdminUtilitarios
    {
        private static SqlCommand command;
        public static List<string> traerColor()
        {
            string consulta = "select distinct color from dbo.Producto";
            command = new SqlCommand(consulta, AdminDB.conectarDB());
            SqlDataReader reader = command.ExecuteReader();
            List<string> colores = new List<string>();
            while (reader.Read())
            {
                colores.Add(reader["color"].ToString());
            }
            reader.Close();
            AdminDB.conectarDB().Close();

            return colores;
        }

        public static List<Producto> PrecioMayor (decimal precioMayor) //despues Probar
        {
            string consulta = "SELECT Id,Nombre,Color,Precio FROM dbo.Producto where Precio = @Precio";
            command = new SqlCommand(consulta, AdminDB.conectarDB());
            command.Parameters.Add("@Precio", SqlDbType.Decimal).Value = precioMayor;
            SqlDataReader reader = command.ExecuteReader();
            List<Producto> productos = new List<Producto>();
            while (reader.Read())
            {
                productos.Add(new Producto()
                {
                    Id = Convert.ToInt32(reader["Id"]),
                    Nombre = reader["Nombre"].ToString(),
                    Color = reader["Color"].ToString(),
                    Precio = Convert.ToDecimal(reader["Precio"])
                });
            }
            reader.Close();
            AdminDB.conectarDB().Close();

            return productos;
        }
    }
}
